<h2>Reportes de Inicio</h2>
<hr>
<table id="tablereportinit" class="table table-hover table-bordered table-striped dataTable_camilo" width="100%">
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
    </tfoot>
</table>


<hr style="margin-bottom: 3em;">

<hr style="margin-top: 3em;">

<h2>Reportes de Actualización</h2>
<br>
<table id="tablereportAct" class="table table-hover table-bordered table-striped dataTable_camilo" width="100%">
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <!-- <th></th> -->
        </tr>
    </tfoot>
</table>


