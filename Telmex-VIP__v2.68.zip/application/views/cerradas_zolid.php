<h2>Reportes de Inicio</h2>
<hr>
<table id="tableCerradasZolid" class="table table-hover table-bordered table-striped dataTable_camilo" width="100%">
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
    </tfoot>
</table>



