<h3>OTHs Asociadas</h3>

<table id="tableOTHSAsc" class="table table-hover table-bordered table-striped dataTable_camilo" style="text-align:center">
    <tfoot>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <!-- <th></th> -->
            <th></th>
            <th></th>
        </tr>
    </tfoot>
</table>


<script>
 var oths = `<?php print_r($oth) ?>`;
</script>