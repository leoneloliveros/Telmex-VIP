## List of donators

* Richard C Jordan - $35
* Janet Moery - $5
* Rene Halskov - $10
* Angel Arambula Garcia - $5
* David Graham - $5
* Paul Abbott - $20
* Philip Tepfer - $10
* Marcus Eddy - $5
* Keith Rockhold - $50
* Ramon Sosa Diaz - $10
* Goncalo Cordeiro - $25
* Marzena Wspanialy - $10
* Nicolas Pascual - $10
* Hassan Ejaz - $10
* Frank Hines - $100
* Luis Triana Vega - $10
* PROMOTUX DI FRANCESCO MELONI E C. S.N.C. - $15
* Emmanuel Kielichowski - $15
* 우공이산 우공이산 - $50
* Empirica srl - $15
* Hassan Gareballa - $10
* 지황 이 - $10
* Onur Kose - $15
* Александр Вейсов - $30
* Anton Blinov - $30
* THARAKESH PULIKONDA - $10
* Linear Design Group, LLC - $20
* Alon Feldman - $100
* Fabian de Rosa - $5
* Zhe Wang - $35

## 支付宝

* 萃华：10.18元
* 小马哥：5元
* 振：20元
* 懒虫：8.8元
* rainc：50元
* 印：10元
* 大个子：50元
* 拓海真一：100元
* IO芒果：7元
* 醉、千秋：18.88元
* 路人甲：5.27元

## 微信

* 一牛九毛：100元
* 笑：50元
* 111111：4元
* 佚名：6.6元
* Evo4me：30元
* zhang：50.05元
* 郝亮：20元
* 王挺：6.6元
* 无心向你：9.9元
* 指间沙：9.9元
* 董琛：9.9元
