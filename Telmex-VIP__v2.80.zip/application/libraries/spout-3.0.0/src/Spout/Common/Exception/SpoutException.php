<?php

namespace Box\Spout\Common\Exception;

/**
 * Class SpoutException
 *
 * @abstract
 */
abstract class SpoutException extends \Exception
{
}
